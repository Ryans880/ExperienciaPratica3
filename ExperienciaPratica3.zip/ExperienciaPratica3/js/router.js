const conteudo = document.getElementById("conteudo");

const paginas = {
  home: `
    <h2>Bem-vindo à ONG Esperança Viva</h2>
    <p>Nosso objetivo é transformar vidas por meio da solidariedade. Faça parte dessa corrente do bem!</p>
    <img src="https://source.unsplash.com/800x300/?charity,people" alt="Imagem da ONG" style="width:100%;border-radius:10px;margin-top:10px;">
  `,
  cadastro: `
    <h2>Cadastro de Voluntário</h2>
    <form id="formCadastro">
      <label>Nome:</label>
      <input type="text" id="nome" placeholder="Seu nome completo" required>
      <label>Email:</label>
      <input type="email" id="email" placeholder="seuemail@exemplo.com" required>
      <button type="submit">Enviar</button>
    </form>
    <p id="msg"></p>
  `,
  contato: `
    <h2>Fale Conosco</h2>
    <p>📧 Email: contato@esperancaviva.org</p>
    <p>📞 Telefone: (11) 90000-0000</p>
    <p>📍 Endereço: Rua da Esperança, 123 - São Paulo/SP</p>
  `
};

// Função para carregar o conteúdo da página
function carregarPagina(pagina) {
  conteudo.innerHTML = paginas[pagina];
  if (pagina === "cadastro") configurarFormulario();
}

// Adiciona eventos de clique nos botões do menu
document.querySelectorAll("button[data-page]").forEach(btn => {
  btn.addEventListener("click", () => carregarPagina(btn.dataset.page));
});

// Exibe a página inicial ao carregar o site
carregarPagina("home");

// Função para configurar o formulário de cadastro
function configurarFormulario() {
  const form = document.getElementById("formCadastro");
  const msg = document.getElementById("msg");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();

    if (!nome || !email) {
      msg.textContent = "⚠️ Por favor, preencha todos os campos!";
      msg.style.color = "red";
      return;
    }

    msg.textContent = "✅ Cadastro realizado com sucesso! Obrigado por se voluntariar.";
    msg.style.color = "green";
    form.reset();
  });
}